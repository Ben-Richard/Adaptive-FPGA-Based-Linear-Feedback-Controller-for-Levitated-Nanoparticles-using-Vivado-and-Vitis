`timescale 1ns/1ps

module tb_fabric_chain;

  // ==== Simulation parameters ====
  localparam real FS_HZ   = 1_000_000.0;  // 1 MHz sample rate (Red Pitaya is 50MHz)
  localparam real TCLK_NS = 1e9 / FS_HZ;  // 1000 ns period = 1 us
  localparam int  N_SAMPS = 5000;         // capture 5 ms

  // ==== DUT I/O ====
  reg                  clk   = 1'b0;
  reg                  reset = 1'b1;
  reg  signed [13:0]   din;               // Q1.13
  wire signed [13:0]   dout;              // Q1.13

  // ==== 1 MHz clock ====
  always #(TCLK_NS/2.0) clk = ~clk;       // 500 ns high/low

  // ==== DUT under test (uses your fabric_chain defaults: Fs=1MHz, f0=30kHz, Q?3) ====
  fabric_chain dut (
    .clk  (clk),
    .reset(reset),
    .din  (din),
    .dout (dout)
  );

  // ==== Helper: real -> Q1.13 ====
  function automatic int q13(input real x);
    real v;
    begin
      if (x >  0.999) v =  0.999;
      else if (x < -0.999) v = -0.999;
      else v = x;
      q13 = $rtoi(v * 8191.0);           // +/-8191 range
    end
  endfunction

  // ==== Multi-tone stimulus + CSV logging ====
  integer fd;
  initial begin
    fd = $fopen("sim_io.csv","w");
    $fwrite(fd, "n,adc_q13,dac_q13\n");

    // deassert reset after a few clocks
    repeat (8) @(posedge clk);
    reset = 1'b0;

    // 5 tones: 10k,20k,30k,40k,50k Hz (each ~0.3 FS). 30k should pass the band.
    for (int n = 0; n < N_SAMPS; n++) begin
      real t = n / FS_HZ;                // REAL division (no truncation)
      real s = 0.0;
      s += 0.30 * $sin(2.0*3.1415926535*10_000.0 * t);
      s += 0.30 * $sin(2.0*3.1415926535*20_000.0 * t);
      s += 0.30 * $sin(2.0*3.1415926535*30_000.0 * t); // should pass
      s += 0.30 * $sin(2.0*3.1415926535*40_000.0 * t);
      s += 0.30 * $sin(2.0*3.1415926535*50_000.0 * t);

      din = q13(s);                       // quantise to Q1.13
      @(posedge clk);
      $fwrite(fd, "%0d,%0d,%0d\n", n, $signed(din), $signed(dout));
    end

    $fclose(fd);
    $stop;
  end

endmodule
