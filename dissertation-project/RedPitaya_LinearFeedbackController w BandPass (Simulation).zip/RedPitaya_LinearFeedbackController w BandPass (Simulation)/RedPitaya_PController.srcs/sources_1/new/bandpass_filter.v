// biquad_bandpass_fixed.v  (Transposed DF-II)
// 14-bit data in/out (Q1.13). Coeffs are Q2.14 (16-bit).
module biquad_bandpass_fixed #(
    parameter signed [15:0] B0_Q14 = 16'sd2,
    parameter signed [15:0] B1_Q14 = 16'sd0,
    parameter signed [15:0] B2_Q14 = -16'sd2,
    parameter signed [15:0] A1_Q14 = -16'sd32764,
    parameter signed [15:0] A2_Q14 =  16'sd16380
)(
    input  wire                clk,
    input  wire                reset,
    input  wire signed  [13:0] x_in,   // Q1.13
    output reg  signed  [13:0] y_out   // Q1.13
);
    reg signed [31:0] z1 = 0, z2 = 0;
    reg signed [31:0] y_tmp;

    function automatic signed [31:0] mul_q14;
        input signed [13:0] s;  // Q1.13
        input signed [15:0] c;  // Q2.14
        reg   signed [29:0] p;
        begin
            p = $signed(s) * $signed(c);  // Q3.27
            mul_q14 = $signed(p) >>> 14;  // -> Q1.13
        end
    endfunction

    function automatic signed [13:0] sat14;
        input signed [31:0] v;
        begin
            if (v >  32'sd8191)      sat14 =  14'sd8191;
            else if (v < -32'sd8192) sat14 = -14'sd8192;
            else                     sat14 = v[13:0];
        end
    endfunction

    always @(posedge clk) begin
        if (reset) begin
            z1 <= 0; z2 <= 0; y_out <= 0;
        end else begin
            y_tmp = mul_q14(x_in, B0_Q14) + z1; // y = b0*x + z1
            z1   <= mul_q14(x_in, B1_Q14) + z2 - mul_q14(sat14(y_tmp), A1_Q14);
            z2   <= mul_q14(x_in, B2_Q14)      - mul_q14(sat14(y_tmp), A2_Q14);
            y_out <= sat14(y_tmp);
        end
    end
endmodule
