module top();

  // BD wrapper external buses
  wire         clk;               // from PS FCLK (exported by BD)
  wire [13:0]  adc_data;          // IN1 samples into fabric (14-bit)
  wire [13:0]  dac_data;          // OUT1 samples from fabric (14-bit)

  // Instantiate the BD wrapper (names must match your BD)
  red_pitaya_bd_wrapper bd_inst (
    .DDR_addr(), .DDR_ba(), .DDR_cas_n(), .DDR_ck_n(), .DDR_ck_p(),
    .DDR_cke(), .DDR_cs_n(), .DDR_dm(), .DDR_dq(), .DDR_dqs_n(),
    .DDR_dqs_p(), .DDR_odt(), .DDR_ras_n(), .DDR_reset_n(), .DDR_we_n(),
    .FIXED_IO_ddr_vrn(), .FIXED_IO_ddr_vrp(), .FIXED_IO_mio(),
    .FIXED_IO_ps_clk(), .FIXED_IO_ps_porb(), .FIXED_IO_ps_srstb(),
    .adc_data(adc_data),
    .dac_data(dac_data),
    .clk(clk)
  );

  // --- Signal path: ADC -> Band-pass -> Delay -> Kp -> DAC ---
  wire signed [13:0] adc_s14 = adc_data;
  wire signed [13:0] bp_out, delayed, ctrl_s14;

  // Hard-coded biquad (put your Q2.14 params here)
//  biquad_bandpass_fixed #(
//    .B0_Q14(16'sd2),     // example Fs=50 MHz, f0=10 kHz, Q=5
//    .B1_Q14(16'sd0),
//    .B2_Q14(-16'sd2),
//    .A1_Q14(-16'sd32764),
//    .A2_Q14(16'sd16380)
//  ) bp (
//    .clk(clk),
//    .reset(1'b0),
//    .x_in(adc_s14),
//    .y_out(bp_out)
//  );

  // 1-cycle delay
//  time_delay delay_inst (
//    .clk(clk),
//    .din(bp_out),
//    .dout(delayed)
//  );

  // Fixed-Kp controller (Q2.14: 1.00 = 16384)
//  p_controller_fixed #(.KP_Q14(16'sd16384)) pctl (
//    .clk(clk),
//    .ain(delayed),
//    .aout(ctrl_s14)
//  );

  // Drive DAC (already 14-bit)
//  assign dac_data = ctrl_s14;

// === STEP-1 BYPASS: fabric pass-through ===
assign dac_data = adc_data;   // OUT1 should mirror IN1

endmodule
