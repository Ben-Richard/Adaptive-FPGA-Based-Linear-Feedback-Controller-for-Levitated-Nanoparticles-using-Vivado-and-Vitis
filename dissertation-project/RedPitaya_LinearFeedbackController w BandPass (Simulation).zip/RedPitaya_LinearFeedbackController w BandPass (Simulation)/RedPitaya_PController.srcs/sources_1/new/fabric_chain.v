// fabric_chain.v
// din -> band-pass (biquad) -> delay -> Kp -> dout
// Q1.13 data, Q2.14 coeffs.
// Default: Fs=1 MHz, f0=30 kHz, phase shift = 90� at f0.

module fabric_chain #(
    // --- Biquad coeffs (Q2.14) computed for Fs=1 MHz, f0=30 kHz, Q=3 ---
    // b0= +0.030284 -> +496, b1=0, b2=-0.030284 -> -496
    // a1= -1.905078 -> -31213, a2= +0.939431 -> +15392
    parameter signed [15:0] B0_Q14 = 16'sd496,
    parameter signed [15:0] B1_Q14 = 16'sd0,
    parameter signed [15:0] B2_Q14 = -16'sd496,
    parameter signed [15:0] A1_Q14 = -16'sd31213,
    parameter signed [15:0] A2_Q14 =  16'sd15392,

    // --- Proportional gain (Q2.14). 16384 = 1.0 ---
    parameter signed [15:0] KP_Q14 = 16'sd16384,

    // --- Timing for auto-delay (affects only delay samples) ---
    parameter integer FS_HZ     = 1_000_000, // sample rate (Hz)
    parameter integer F0_HZ     = 30_000,    // band center (Hz)

    // --- Phase at f0 (degrees) when using auto-delay ---
    parameter integer PHASE_DEG = 90,        // e.g. 0, 45, 90, 120, 180 �

    // --- Optionally override with explicit sample delay ---
    parameter integer USE_EXPLICIT_DELAY = 0, // 0=auto from phase, 1=use EXPLICIT_DELAY
    parameter integer EXPLICIT_DELAY     = 0  // used only when USE_EXPLICIT_DELAY=1
)(
    input  wire               clk,    // Fs clock
    input  wire               reset,  // synchronous
    input  wire signed [13:0] din,    // Q1.13
    output wire signed [13:0] dout    // Q1.13
);

    // -------------------- Auto-compute delay samples from phase --------------------
    // Samples for a given phase at f0:
    //   N(?) = round( Fs * (?/360) / f0 ) = round( Fs * ? / (360 * f0) )
    // Use integer rounding: (num + den/2) / den
    localparam integer DEN        = (360 * (F0_HZ > 0 ? F0_HZ : 1));
    localparam integer NUM_RAW    = FS_HZ * (PHASE_DEG < 0 ? 0 : PHASE_DEG); // clamp ?>=0
    localparam integer N_PHASE    = (NUM_RAW + (DEN/2)) / DEN;               // rounded
    localparam integer N_AUTO     = (N_PHASE < 0) ? 0 : N_PHASE;             // safety clamp

    localparam integer DELAY_SAMPS = (USE_EXPLICIT_DELAY != 0) ? EXPLICIT_DELAY : N_AUTO;

    // -------------------- Signal plumbing --------------------
    wire signed [13:0] bp_out;
    wire signed [13:0] dly_out;
    wire signed [13:0] kp_out;

    // --- Band-pass biquad ---
    biquad_bandpass_fixed #(
        .B0_Q14(B0_Q14), .B1_Q14(B1_Q14), .B2_Q14(B2_Q14),
        .A1_Q14(A1_Q14), .A2_Q14(A2_Q14)
    ) u_bpf (
        .clk  (clk),
        .reset(reset),
        .x_in (din),
        .y_out(bp_out)
    );

    // --- Delay (auto by phase at f0, or explicit samples) ---
    time_delay #(.DELAY(DELAY_SAMPS)) u_delay (
        .clk (clk),
        .din (bp_out),
        .dout(dly_out)
    );

    // --- Proportional controller ---
    p_controller_fixed #(.KP_Q14(KP_Q14)) u_pctl (
        .clk (clk),
        .ain (dly_out),
        .aout(kp_out)
    );

    assign dout = kp_out;

endmodule
