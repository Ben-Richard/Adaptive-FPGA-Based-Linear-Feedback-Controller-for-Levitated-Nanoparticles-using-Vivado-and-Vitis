// Q2.14 gain
module p_controller_fixed #(
    parameter signed [15:0] KP_Q14 = 16'sd16384  // 1.0
)(
    input  wire                clk,
    input  wire signed  [13:0] ain,   // Q1.13
    output reg  signed  [13:0] aout   // Q1.13
);
    reg signed [29:0] mult;
    always @(posedge clk) begin
        mult <= $signed(ain) * $signed(KP_Q14); // Q3.27
        aout <= $signed(mult >>> 14);           // -> Q1.13
    end
endmodule
