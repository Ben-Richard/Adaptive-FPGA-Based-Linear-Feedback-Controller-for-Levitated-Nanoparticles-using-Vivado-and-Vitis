// time_delay.v : N-sample synchronous delay line (Q1.13)
module time_delay #(
    parameter integer DELAY = 1  // number of clock cycles to delay (>=0)
)(
    input  wire                clk,
    input  wire signed  [13:0] din,
    output reg  signed  [13:0] dout
);
    generate
      if (DELAY <= 0) begin : g_nodelay
        always @(posedge clk) dout <= din;
      end else begin : g_pipe
        reg signed [13:0] sh [0:DELAY-1];
        integer i;
        always @(posedge clk) begin
          sh[0] <= din;
          for (i = 1; i < DELAY; i = i + 1)
            sh[i] <= sh[i-1];
          dout <= sh[DELAY-1];
        end
      end
    endgenerate
endmodule
