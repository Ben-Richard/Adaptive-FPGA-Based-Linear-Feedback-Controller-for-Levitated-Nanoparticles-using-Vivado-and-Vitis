onbreak {quit -f}
onerror {quit -f}

vsim -lib xil_defaultlib red_pitaya_bd_opt

do {wave.do}

view wave
view structure
view signals

do {red_pitaya_bd.udo}

run -all

quit -force
