vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/axi_infrastructure_v1_1_0
vlib modelsim_lib/msim/axi_vip_v1_1_7
vlib modelsim_lib/msim/processing_system7_vip_v1_0_9
vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/lib_cdc_v1_0_2
vlib modelsim_lib/msim/proc_sys_reset_v5_0_13
vlib modelsim_lib/msim/xlconstant_v1_1_7

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap axi_infrastructure_v1_1_0 modelsim_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_7 modelsim_lib/msim/axi_vip_v1_1_7
vmap processing_system7_vip_v1_0_9 modelsim_lib/msim/processing_system7_vip_v1_0_9
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap lib_cdc_v1_0_2 modelsim_lib/msim/lib_cdc_v1_0_2
vmap proc_sys_reset_v5_0_13 modelsim_lib/msim/proc_sys_reset_v5_0_13
vmap xlconstant_v1_1_7 modelsim_lib/msim/xlconstant_v1_1_7

vlog -work xilinx_vip  -incr -sv -L axi_vip_v1_1_7 -L processing_system7_vip_v1_0_9 -L xilinx_vip "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work axi_infrastructure_v1_1_0  -incr "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_7  -incr -sv -L axi_vip_v1_1_7 -L processing_system7_vip_v1_0_9 -L xilinx_vip "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ce6c/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_9  -incr -sv -L axi_vip_v1_1_7 -L processing_system7_vip_v1_0_9 -L xilinx_vip "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../bd/red_pitaya_bd/ip/red_pitaya_bd_processing_system7_0_0/sim/red_pitaya_bd_processing_system7_0_0.v" \

vcom -work lib_cdc_v1_0_2  -93 \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ef1e/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_13  -93 \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/8842/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib  -93 \
"../../../bd/red_pitaya_bd/ip/red_pitaya_bd_proc_sys_reset_0_0/sim/red_pitaya_bd_proc_sys_reset_0_0.vhd" \

vlog -work xlconstant_v1_1_7  -incr "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/fcfc/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/ec67/hdl" "+incdir+../../../../RedPitaya_PController.srcs/sources_1/bd/red_pitaya_bd/ipshared/6b56/hdl" "+incdir+C:/Xilinx/Vitis/Vivado/2020.1/data/xilinx_vip/include" \
"../../../bd/red_pitaya_bd/ip/red_pitaya_bd_xlconstant_0_0/sim/red_pitaya_bd_xlconstant_0_0.v" \
"../../../bd/red_pitaya_bd/sim/red_pitaya_bd.v" \

vlog -work xil_defaultlib \
"glbl.v"

